package tests;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.AccountPage;
import pages.LoginPage;
import pages.RegistrationPage;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AccountTransferTest {
    private static final String TRANSFER_VALUE = "1000";
    private static final String TRANSFER_DESCRIPTION = "devo não nego pago quando puder";

    @Test
    public void testAccountTransfer() {
        // Lê o arquivo de configuração
        Properties config = new Properties();
        try (FileInputStream input = new FileInputStream("src/test/resources/config.properties")) {
            config.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Configura o driver do navegador
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\javal\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        // Cria uma instância da página de registro
        RegistrationPage registrationPage = new RegistrationPage(driver);

        // Acessa o site e clica no botão "Registrar"
        registrationPage.navigateToSite();
        registrationPage.clickRegisterButton();

        // Preenche os campos do formulário de registro com dados da primeira conta
        registrationPage.fillEmail(config.getProperty("TEST_EMAIL_1"));
        registrationPage.fillName("Usuario 1");
        registrationPage.fillPassword(config.getProperty("TEST_PASSWORD_1"));
        registrationPage.fillPasswordConfirmation(config.getProperty("TEST_PASSWORD_1"));

        // Marca a opção "Criar conta com Saldo?"
        registrationPage.toggleAddBalance();

     // Clica no botão "Cadastrar" e depois no botão "Fechar" do modal
        registrationPage.clickSubmitButton();
        registrationPage.clickCloseButton();

     // Acessa a página de login
     registrationPage.navigateToLoginPage();

     // Cria uma instância da página de login
     LoginPage loginPage = new LoginPage(driver);

     // Preenche os campos de email e senha com os dados da primeira conta e clica no botão "Acessar"
     loginPage.fillEmail(config.getProperty("TEST_EMAIL_1"));
     loginPage.fillPassword(config.getProperty("TEST_PASSWORD_1"));
     loginPage.clickAccessButton();

     // Cria uma instância da página da conta
     AccountPage accountPage = new AccountPage(driver);

     // Armazena o número e o dígito da primeira conta
     String firstAccountNumber = accountPage.getAccountNumber();
     String firstAccountDigit = accountPage.getAccountDigit();

     // Clica no botão "Sair"
     accountPage.clickExitButton();

     // Acessa a página de login novamente
     registrationPage.navigateToLoginPage();

     // Preenche os campos de email e senha com os dados da segunda conta e clica no botão "Acessar"
     loginPage.fillEmail(config.getProperty("TEST_EMAIL_2"));
     loginPage.fillPassword(config.getProperty("TEST_PASSWORD_2"));
     loginPage.clickAccessButton();

     // Clica no botão "Transferir"
     accountPage.clickTransferButton();

     // Preenche os campos do formulário de transferência com os dados da primeira conta
     accountPage.fillAccountNumber(firstAccountNumber);
     accountPage.fillDigit(firstAccountDigit);
     accountPage.fillTransferValue(TRANSFER_VALUE);
     accountPage.fillDescription(TRANSFER_DESCRIPTION);

         // Clica no botão "Transferir agora"
         accountPage.clickTransferNowButton();

         // Verifica se a transferência foi realizada com sucesso
         String modalText = accountPage.getModalText();
         assertEquals(modalText, "Transferencia realizada com sucesso");

         // Clica no botão "Fechar" do modal
         accountPage.clickCloseModalButton();

         // Fecha o navegador
         driver.quit();
    }
}
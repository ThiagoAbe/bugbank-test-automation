package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage {
    private WebDriver driver;

    public AccountPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickTransferButton() {
        driver.findElement(By.id("btn-TRANSFERÊNCIA")).click();
    }

    public String getAccountNumber() {
        return driver.findElement(By.id("textAccountNumber")).getText().split(": ")[1].split("-")[0];
    }

    public String getAccountDigit() {
        return driver.findElement(By.id("textAccountNumber")).getText().split(": ")[1].split("-")[1];
    }

    public void clickExitButton() {
        driver.findElement(By.id("btnExit")).click();
    }

    public void fillAccountNumber(String accountNumber) {
        driver.findElement(By.name("accountNumber")).sendKeys(accountNumber);
    }

    public void fillDigit(String digit) {
        driver.findElement(By.name("digit")).sendKeys(digit);
    }

    public void fillTransferValue(String transferValue) {
        driver.findElement(By.name("transferValue")).sendKeys(transferValue);
    }

    public void fillDescription(String description) {
        driver.findElement(By.name("description")).sendKeys(description);
    }

    public void clickTransferNowButton() {
        driver.findElement(By.xpath("//button[text()='Transferir agora']")).click();
    }

    public String getModalText() {
        return driver.findElement(By.id("modalText")).getText();
    }

    public void clickCloseModalButton() {
        driver.findElement(By.id("btnCloseModal")).click();
    }
}
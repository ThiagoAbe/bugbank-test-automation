package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegistrationPage {
    private WebDriver driver;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
    }
    
    public void navigateToSite() {
        driver.get("https://bugbank.netlify.app/");
    }

    public void clickRegisterButton() {
        driver.findElement(By.xpath("//button[text()='Registrar']")).click();
    }

    public void fillEmail(String email) {
        driver.findElement(By.cssSelector("input[type='email']")).sendKeys(email);
    }

    public void fillName(String name) {
        driver.findElement(By.name("name")).sendKeys(name);
    }

    public void fillPassword(String password) {
        driver.findElement(By.cssSelector("input[type='password'][name='password']")).sendKeys(password);
    }

    public void fillPasswordConfirmation(String passwordConfirmation) {
        driver.findElement(By.name("passwordConfirmation")).sendKeys(passwordConfirmation);
    }

    public void toggleAddBalance() {
        driver.findElement(By.id("toggleAddBalance")).click();
    }

    public void clickSubmitButton() {
        driver.findElement(By.xpath("//button[text()='Cadastrar']")).click();
    }
    public void clickCloseButton() {
        driver.findElement(By.id("btnCloseModal")).click();
    }
    public void navigateToLoginPage() {
        driver.get("https://bugbank.netlify.app/login");
    }
}
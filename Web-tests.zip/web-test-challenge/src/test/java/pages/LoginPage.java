package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    private WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void fillEmail(String email) {
        driver.findElement(By.name("email")).sendKeys(email);
    }

    public void fillPassword(String password) {
        driver.findElement(By.name("password")).sendKeys(password);
    }

    public void clickAccessButton() {
        driver.findElement(By.xpath("//button[text()='Acessar']")).click();
    }
}